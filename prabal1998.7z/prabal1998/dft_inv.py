import matplotlib
import matplotlib.pyplot as plt
import scipy
import numpy as np



class Ifft():
# inheritance methods of parent class using super() 
	def __init__(self, dscrt_smpl, freq_smpl_indx, **kwargs):
		self.dscrt_smpl = np.array(dscrt_smpl,dtype=float)
		self.freq_smpl_indx = int(freq_smpl_indx)
		
	def basis(self):
		l=np.array([],dtype=float)
		for n in range(0,len(self.dscrt_smpl)):
				k=(1/np.sqrt(len(self.dscrt_smpl)))*(np.exp([(1j*2*np.pi*self.freq_smpl_indx*n)/(len(self.dscrt_smpl))]))
				l=np.append(l,k)
		basis_arr=l
		#use of setter to store basis sum and basis array
		self.basis_sum=np.sum(l)
		self.basis_arr=basis_arr
		return self.basis_sum, self.basis_arr
	def basis_all(self):
		l=np.array([],dtype=float)
		for freq in range(0,self.freq_smpl_indx):
			for n in range(0,len(self.dscrt_smpl)):
				k=(1/np.sqrt(len(self.dscrt_smpl)))*(np.exp([(1j*2*np.pi*freq*n)/(len(self.dscrt_smpl))]))
				l=np.append(l,k)
			#basis_all=np.append(p,l)
		basis_arr=l.reshape(self.freq_smpl_indx, len(self.dscrt_smpl))
		#basis_arr=basis_arr.reshape()
		#basis_arr_all=basis_all
		#use of setter to store basis sum and basis array
		self.basis_sum_all=basis_arr.sum(axis=1)
		self.basis_arr_all=basis_arr
		return self.basis_sum_all, self.basis_arr_all
	
	def inner_product(self):
		dot_prdct=np.dot(self.dscrt_smpl, self.basis_arr)
		#use of setter to store dot_prdct
		self.dot_prdct=dot_prdct
		return self.dot_prdct

	def inner_product_all(self):
		dot_prdct_all=np.array([],dtype=float)
		for n in range(0,self.freq_smpl_indx):
			dot_prdct=np.dot(self.dscrt_smpl,self.basis_arr_all[n,:])
			dot_prdct_all=np.append(dot_prdct_all,dot_prdct)
		self.dot_prdct_all=dot_prdct_all
		return self.dot_prdct_all

	def freq_trnsfm(self):
		freq_coef=np.array([],dtype=float)
		freq_coef=np.append(freq_coef,self.dot_prdct)
		#use of setter to store freq_coef
		self.freq_coef=freq_coef
			# basis_arr=basis(dscrt_smpl,freq_smpl_indx)
			# dot_prdct=inner_product(dscrt_smpl,basis_arr)
		return self.freq_coef
	
	def freq_trnsfm_all(self):
		freq_coef=np.array([],dtype=float)
		#for freq_smpl_indx in range(0, self.freq_smpl_indx):
		freq_coef=np.append(freq_coef,self.dot_prdct_all)
		#use of setter to store freq_coef
		self.freq_coef_all=freq_coef
			# basis_arr=basis(dscrt_smpl,freq_smpl_indx)
			# dot_prdct=inner_product(dscrt_smpl,basis_arr)
		return self.freq_coef_all

	def plot_1d(self):
		x_data1= np.linspace(0,len(self.dscrt_smpl)-1,num=len(self.dscrt_smpl))
		x_data2=np.linspace(0,self.freq_smpl_indx-1,num=self.freq_smpl_indx)
		fig, (ax1, ax2, ax3) = plt.subplots(3, 1)
		fig.suptitle('Temporal and Frequency domain plot using DFT transform')
		ax1.stem(x_data1,np.real(self.freq_coef_all))
		ax1.set_title('Temporal domain')
		ax1.set_xlabel('Samples [n]')
		ax1.set_ylabel('Magnitude')
		fig.tight_layout()
		
		ax2.stem(x_data2, np.angle(self.freq_coef_all))
		ax2.set_title('Input signal phase')
		ax2.set_xlabel('sample')
		ax2.set_ylabel(' Phase magnitude')
		fig.tight_layout()


		return plt.show()