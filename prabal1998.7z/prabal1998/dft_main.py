import dft_forward
import dft_inv
# The below package should be installed #
import matplotlib
import matplotlib.pyplot as plt
import scipy
import numpy as np
# End of additional package           #
def main():
	#creating sequence array  [0,1) with 0.01 difference in interval 
	x1=np.arange(0,1,0.1)
	
    #creating a input function that resemble standard equation
    #Subjective to change for analysis and observation
	ip = np.cos(2 * np.pi *1* x1) + np.cos(2 * np.pi *2* x1)
	
    #number of samples in DFT 
	print('Enter the number of sample in DFT: ')
	freq_coef_num=int(input())
    #---------------------Start of DFT-----------
    #Uses custom class module Fft. The module is written such a way
    #to obtain sampled harmonic signal,wm,that forms an orthogonal basis 
    #Values are obtained for different value of n to N and finally inner prodcut is obtained with input
    #to get transform.
    # Will be useful to know about orthogonal basis function
	test=dft_forward.Fft(ip,freq_coef_num)
	bsis_sum, bsis_arr=test.basis()                                                                      
	bsis_sum_all, bsis_arr_all =test.basis_all()
	dot_prdct=test.inner_product()
	dot_prdct_all=test.inner_product_all()
	freq_coef=test.freq_trnsfm_all() 
	plot=test.plot_1d()

    #------------------End of DFT-----------------#


    #----------Start of autocorrelation-----------#

    #Concept of autocorrelation includes
    #1. Input function sequence, f(n)
    #2. Windowed to avoid leakage as discontinuty may not end exactly at period N
    #3. After #2. DFT show approx. DTFT of the signal within window so perform DFT
    #4. Take absolute vale of DFT |DFT|^2
    #5. Perform IDFT of #4.
    #6. Autocorrelation function
 
	#1 multiply by windows function with input function sequence
	win_sig=test.win_multiply()
	#2.DFT windowed signal 
	testx=dft_forward.Fft(win_sig,freq_coef_num)
    #Steps to obtain DFT
	bsis_sum, bsis_arr=testx.basis()                                                                      
	bsis_sum_all, bsis_arr_all =testx.basis_all()
	dot_prdct=testx.inner_product()
	dot_prdct_all=testx.inner_product_all()
	freq_coef_auto=testx.freq_trnsfm_all()
      
	#3 Magnitude of DFT 
	freq_coef_abs=np.absolute(freq_coef_auto)
	
    #inverse DFT number of samples
	print('Enter the number of samples in time domain: ')
	tdm_smpl_indx=int(input())
    
    #Similar steps for inverse as in forward 
	testx_inv=dft_inv.Ifft(freq_coef_abs,tdm_smpl_indx)
	bsis_sum, bsis_arr=testx_inv.basis()                                                                     
	bsis_sum_all, bsis_arr_all =testx_inv.basis_all()
	dot_prdct=testx_inv.inner_product()
	dot_prdct_all=testx_inv.inner_product_all()
	freq_coef_x=testx_inv.freq_trnsfm_all() 
    #Plot of autocorrelation function
	plt.plot(np.real(freq_coef_x))
	plt.title("Autocorrelation function")
	plt.show()
   
   #--------End of auto correlation --------------------#


   #--------Start of inverse DFT------------------------#
    # This step is to perform inverse DFT of complex transform coefficients
    # obtained from previous earlier step.
	freq_smpl= np.array(freq_coef)

	test2=dft_inv.Ifft(freq_smpl,tdm_smpl_indx)
	bsis_sum, bsis_arr=test2.basis()                                                                     
	bsis_sum_all, bsis_arr_all =test2.basis_all()
	dot_prdct=test2.inner_product()
	dot_prdct_all=test2.inner_product_all()
	freq_coef=test2.freq_trnsfm_all() 
	plot=test2.plot_1d()
#----------------End of inverse DFT-----------------#
	
	



#construct is used to check if the Python script is being run directly (as the main program) 
#or if it is being imported as a module into another script.
if __name__ == '__main__':
    main() 